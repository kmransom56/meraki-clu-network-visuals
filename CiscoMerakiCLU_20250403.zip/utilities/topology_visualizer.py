"""
Network Topology Visualization Module

This module provides functions to visualize Meraki network topology
with different device types and connection types.
"""

import os
import json
import logging
import webbrowser
from pathlib import Path

# Device type to icon mapping
DEVICE_ICONS = {
    'MX': 'router',
    'MS': 'switch',
    'MR': 'wifi',
    'MG': 'cell_tower',
    'MV': 'videocam',
    'MT': 'sensors',
    'Z': 'router',
    'cloud': 'cloud',
    'client': 'computer',
    'Mobile': 'smartphone',
    'Laptop': 'laptop',
    'Desktop': 'desktop_windows',
    'Printer': 'print',
    'Camera': 'videocam',
    'IoT': 'settings_remote',
    'Unknown': 'device_unknown'
}

# Connection type to style mapping
CONNECTION_STYLES = {
    'uplink': {'color': '#00C853', 'width': 3, 'dashes': False, 'label': 'Uplink'},
    'switch': {'color': '#2196F3', 'width': 2, 'dashes': False, 'label': 'Switch Connection'},
    'wireless': {'color': '#FF9800', 'width': 2, 'dashes': True, 'label': 'Wireless Connection'},
    'wired': {'color': '#607D8B', 'width': 1, 'dashes': False, 'label': 'Wired Client'},
    'unknown': {'color': '#9E9E9E', 'width': 1, 'dashes': True, 'label': 'Unknown Connection'}
}

def generate_topology_html(topology_data, network_name=None, output_path=None):
    """
    Generate an HTML file to visualize network topology
    
    Args:
        topology_data (dict): Network topology data with nodes and links
        network_name (str, optional): Name of the network. If None, will use from topology_data.
        output_path (str, optional): Path to save the HTML file. Defaults to None.
        
    Returns:
        str: Path to the generated HTML file
    """
    # Use network name from topology data if not provided
    if network_name is None and 'network_name' in topology_data:
        network_name = topology_data['network_name']
    elif network_name is None:
        network_name = "Unknown Network"
        
    if not output_path:
        # Create a directory for topology visualizations if it doesn't exist
        output_dir = Path(os.path.expanduser("~")) / "meraki_visualizations"
        os.makedirs(output_dir, exist_ok=True)
        output_path = output_dir / f"{network_name.replace(' ', '_')}_topology.html"
    
    # Convert topology data to vis.js format
    vis_nodes = []
    vis_edges = []
    
    # Process nodes
    for node in topology_data.get('nodes', []):
        node_type = node.get('type', 'Unknown')
        icon = DEVICE_ICONS.get(node_type, 'device_unknown')
        
        # Customize node appearance based on type
        shape = 'image'
        size = 30
        font_size = 14
        
        # For client devices, use smaller size and include OS info
        if node_type == 'client':
            size = 20
            font_size = 12
            
            # Use client_type icon if available
            client_type = node.get('client_type', 'Unknown')
            if client_type in DEVICE_ICONS:
                icon = DEVICE_ICONS[client_type]
            
            # Create detailed tooltip with all client information
            title_content = f"""<b>{node.get('label', 'Unknown')}</b>
<hr>
<b>MAC:</b> {node.get('mac', 'Unknown')}<br>
<b>IP:</b> {node.get('ip', 'Unknown')}<br>
<b>OS:</b> {node.get('os', 'Unknown')}<br>
<b>Type:</b> {client_type}<br>
<b>Manufacturer:</b> {node.get('manufacturer', 'Unknown')}<br>
<b>VLAN:</b> {node.get('vlan', 'Unknown')}"""
            
            # Add port information if available
            if node.get('port'):
                title_content += f"""<br>
<b>Port:</b> {node.get('port', 'Unknown')}<br>
<b>Port Status:</b> {node.get('port_status', 'Unknown')}<br>
<b>Port Speed:</b> {node.get('port_speed', 'Unknown')}"""
            
            # Add last seen information
            if node.get('last_seen'):
                title_content += f"<br><b>Last Seen:</b> {node.get('last_seen', 'Unknown')}"
        else:
            title_content = f"<b>{node.get('label', 'Unknown')}</b><br>Model: {node.get('model', 'Unknown')}<br>Type: {node_type}<br>IP: {node.get('ip', 'Unknown')}"
        
        vis_node = {
            'id': node['id'],
            'label': node.get('label', node['id']),
            'title': title_content,
            'shape': shape,
            'image': f"https://img.icons8.com/material/48/{icon}.png",
            'group': node_type,
            'size': size,
            'font': {
                'size': font_size
            }
        }
        vis_nodes.append(vis_node)
    
    # Process links
    connection_types = set()
    for link in topology_data.get('links', []):
        link_type = link.get('type', 'unknown')
        connection_types.add(link_type)
        style = CONNECTION_STYLES.get(link_type, CONNECTION_STYLES['unknown'])
        
        # Create a descriptive label based on the connection type
        label = ""
        if link_type == "uplink":
            label = "Internet Connection"
        elif link_type == "switch":
            label = f"Switch Port: {link.get('interface', 'unknown')}"
        elif link_type == "wireless":
            label = "Wireless Connection"
        elif link_type == "wired":
            # For wired connections, show port and VLAN if available
            interface_info = link.get('interface', 'unknown')
            if 'Port' in interface_info:
                label = interface_info
            else:
                label = f"VLAN: {interface_info}"
        
        vis_edge = {
            'from': link['source'],
            'to': link['target'],
            'title': f"Type: {style['label']}<br>Interface: {link.get('interface', 'Unknown')}",
            'color': style['color'],
            'width': style['width'],
            'dashes': style['dashes'],
            'label': label,
            'font': {'size': 10, 'color': style['color'], 'face': 'arial', 'background': 'white'},
            'arrows': {
                'to': {
                    'enabled': True,
                    'scaleFactor': 0.5
                }
            }
        }
        vis_edges.append(vis_edge)
    
    # Generate HTML with vis.js
    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <title>Meraki Network Topology - {network_name}</title>
    <meta charset="utf-8">
    <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
    <style type="text/css">
        body, html {{
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }}
        #topology-container {{
            width: 100%;
            height: 100%;
            background-color: #f9f9f9;
        }}
        #network-info {{
            position: absolute;
            top: 10px;
            left: 10px;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1;
        }}
        .legend {{
            position: absolute;
            bottom: 10px;
            right: 10px;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1;
            max-height: 200px;
            overflow-y: auto;
        }}
        .legend-item {{
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }}
        .legend-color {{
            width: 20px;
            height: 3px;
            margin-right: 5px;
        }}
        .legend-dash {{
            border-top: 3px dashed;
            width: 20px;
            margin-right: 5px;
        }}
        .controls {{
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1;
        }}
        button {{
            margin: 5px;
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            background-color: #2196F3;
            color: white;
            cursor: pointer;
        }}
        button:hover {{
            background-color: #0b7dda;
        }}
        .filters {{
            position: absolute;
            top: 10px;
            right: 200px;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            z-index: 1;
        }}
        .checkbox-container {{
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }}
        .checkbox-container input {{
            margin-right: 5px;
        }}
    </style>
</head>
<body>
    <div id="network-info">
        <h2>Network: {network_name}</h2>
        <p>Devices: {len([n for n in topology_data.get('nodes', []) if n.get('type') != 'client' and n.get('type') != 'cloud'])}</p>
        <p>Clients: {len([n for n in topology_data.get('nodes', []) if n.get('type') == 'client'])}</p>
        <p>Connections: {len(topology_data.get('links', []))}</p>
    </div>
    
    <div class="controls">
        <button id="zoom-in">Zoom In</button>
        <button id="zoom-out">Zoom Out</button>
        <button id="fit">Fit View</button>
    </div>
    
    <div class="filters">
        <h3>Filters</h3>
        <div class="checkbox-container">
            <input type="checkbox" id="show-clients" checked>
            <label for="show-clients">Show Clients</label>
        </div>
        <div class="checkbox-container">
            <input type="checkbox" id="show-labels" checked>
            <label for="show-labels">Show Labels</label>
        </div>
        <div class="checkbox-container">
            <input type="checkbox" id="show-wired-clients" checked>
            <label for="show-wired-clients">Wired Clients</label>
        </div>
        <div class="checkbox-container">
            <input type="checkbox" id="show-wireless-clients" checked>
            <label for="show-wireless-clients">Wireless Clients</label>
        </div>
    </div>
    
    <div class="legend">
        <h3>Connection Types</h3>
"""

    # Dynamically generate legend based on connection types present in the data
    for conn_type in connection_types:
        style = CONNECTION_STYLES.get(conn_type, CONNECTION_STYLES['unknown'])
        if style['dashes']:
            html_content += f"""
        <div class="legend-item">
            <div class="legend-dash" style="border-color: {style['color']};"></div>
            <span>{style['label']}</span>
        </div>"""
        else:
            html_content += f"""
        <div class="legend-item">
            <div class="legend-color" style="background-color: {style['color']};"></div>
            <span>{style['label']}</span>
        </div>"""

    # Add device type legend
    device_types = set(node.get('type', 'Unknown') for node in topology_data.get('nodes', []))
    client_types = set(node.get('client_type', 'Unknown') for node in topology_data.get('nodes', []) 
                      if node.get('type') == 'client' and node.get('client_type'))
    
    if device_types:
        html_content += """
        <h3>Device Types</h3>"""
        for device_type in device_types:
            if device_type in DEVICE_ICONS:
                icon = DEVICE_ICONS[device_type]
                html_content += f"""
        <div class="legend-item">
            <img src="https://img.icons8.com/material/24/{icon}.png" style="width: 16px; height: 16px; margin-right: 5px;">
            <span>{device_type}</span>
        </div>"""
    
    # Add client type legend if we have client devices
    if client_types:
        html_content += """
        <h3>Client Types</h3>"""
        for client_type in client_types:
            if client_type in DEVICE_ICONS:
                icon = DEVICE_ICONS[client_type]
                html_content += f"""
        <div class="legend-item">
            <img src="https://img.icons8.com/material/24/{icon}.png" style="width: 16px; height: 16px; margin-right: 5px;">
            <span>{client_type}</span>
        </div>"""

    html_content += """
    </div>
    
    <div id="topology-container"></div>
    
    <script type="text/javascript">
        // Create a network
        var container = document.getElementById('topology-container');
        
        // Provide the data in the vis format
        var data = {
            nodes: new vis.DataSet(""" + json.dumps(vis_nodes) + """),
            edges: new vis.DataSet(""" + json.dumps(vis_edges) + """)
        };
        
        // Options for the network
        var options = {
            nodes: {
                size: 30,
                font: {
                    size: 14
                },
                borderWidth: 2,
                shadow: true
            },
            edges: {
                smooth: {
                    type: 'continuous'
                },
                shadow: true
            },
            physics: {
                stabilization: true,
                barnesHut: {
                    gravitationalConstant: -10000,
                    springConstant: 0.002,
                    springLength: 150
                }
            },
            groups: {
                MX: {color: {background: '#E1F5FE', border: '#0288D1'}},
                MS: {color: {background: '#E8F5E9', border: '#388E3C'}},
                MR: {color: {background: '#FFF3E0', border: '#F57C00'}},
                MG: {color: {background: '#F3E5F5', border: '#7B1FA2'}},
                MV: {color: {background: '#FFEBEE', border: '#D32F2F'}},
                MT: {color: {background: '#E0F2F1', border: '#00796B'}},
                Z: {color: {background: '#E3F2FD', border: '#1976D2'}},
                client: {color: {background: '#EFEBE9', border: '#5D4037'}},
                cloud: {color: {background: '#F5F5F5', border: '#616161'}},
                Unknown: {color: {background: '#FAFAFA', border: '#9E9E9E'}}
            },
            interaction: {
                hover: true,
                tooltipDelay: 200,
                hideEdgesOnDrag: true,
                navigationButtons: true,
                keyboard: true
            }
        };
        
        // Initialize the network
        var network = new vis.Network(container, data, options);
        
        // Add event listeners
        network.on("click", function(params) {
            if (params.nodes.length > 0) {
                var nodeId = params.nodes[0];
                var node = data.nodes.get(nodeId);
                console.log("Node clicked:", node);
            }
        });
        
        // Add controls functionality
        document.getElementById('zoom-in').addEventListener('click', function() {
            network.zoom(0.2);
        });
        
        document.getElementById('zoom-out').addEventListener('click', function() {
            network.zoom(-0.2);
        });
        
        document.getElementById('fit').addEventListener('click', function() {
            network.fit();
        });
        
        // Add filter functionality
        document.getElementById('show-clients').addEventListener('change', function() {
            var clientNodes = data.nodes.get({
                filter: function(node) {
                    return node.group === 'client';
                }
            });
            
            var clientEdges = data.edges.get({
                filter: function(edge) {
                    return clientNodes.some(function(node) {
                        return edge.from === node.id || edge.to === node.id;
                    });
                }
            });
            
            if (this.checked) {
                // Show clients
                clientNodes.forEach(function(node) {
                    data.nodes.update({id: node.id, hidden: false});
                });
                clientEdges.forEach(function(edge) {
                    data.edges.update({id: edge.id, hidden: false});
                });
            } else {
                // Hide clients
                clientNodes.forEach(function(node) {
                    data.nodes.update({id: node.id, hidden: true});
                });
                clientEdges.forEach(function(edge) {
                    data.edges.update({id: edge.id, hidden: true});
                });
            }
        });
        
        // Add wired/wireless client filters
        document.getElementById('show-wired-clients').addEventListener('change', function() {
            var wiredEdges = data.edges.get({
                filter: function(edge) {
                    return edge.type === 'wired';
                }
            });
            
            var wiredClientIds = wiredEdges.map(edge => edge.to);
            
            if (this.checked) {
                // Show wired clients
                wiredClientIds.forEach(function(id) {
                    data.nodes.update({id: id, hidden: false});
                });
                wiredEdges.forEach(function(edge) {
                    data.edges.update({id: edge.id, hidden: false});
                });
            } else {
                // Hide wired clients
                wiredClientIds.forEach(function(id) {
                    data.nodes.update({id: id, hidden: true});
                });
                wiredEdges.forEach(function(edge) {
                    data.edges.update({id: edge.id, hidden: false});
                });
            }
        });
        
        document.getElementById('show-wireless-clients').addEventListener('change', function() {
            var wirelessEdges = data.edges.get({
                filter: function(edge) {
                    return edge.type === 'wireless';
                }
            });
            
            var wirelessClientIds = wirelessEdges.map(edge => edge.to);
            
            if (this.checked) {
                // Show wireless clients
                wirelessClientIds.forEach(function(id) {
                    data.nodes.update({id: id, hidden: false});
                });
                wirelessEdges.forEach(function(edge) {
                    data.edges.update({id: edge.id, hidden: false});
                });
            } else {
                // Hide wireless clients
                wirelessClientIds.forEach(function(id) {
                    data.nodes.update({id: id, hidden: true});
                });
                wirelessEdges.forEach(function(edge) {
                    data.edges.update({id: edge.id, hidden: false});
                });
            }
        });
    </script>
</body>
</html>
"""
    
    # Write HTML to file
    with open(output_path, 'w') as f:
        f.write(html_content)
    
    logging.info(f"Network topology visualization saved to {output_path}")
    return str(output_path)

def open_topology_visualization(html_path):
    """
    Open the topology visualization in the default web browser
    
    Args:
        html_path (str): Path to the HTML file
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        webbrowser.open(f"file://{html_path}")
        return True
    except Exception as e:
        logging.error(f"Error opening topology visualization: {str(e)}")
        return False

def visualize_network_topology(topology_data, network_name=None):
    """
    Generate and open a network topology visualization
    
    Args:
        topology_data (dict): Network topology data with nodes and links
        network_name (str, optional): Name of the network. If None, will use from topology_data.
        
    Returns:
        str: Path to the generated HTML file or None if failed
    """
    try:
        html_path = generate_topology_html(topology_data, network_name)
        open_topology_visualization(html_path)
        return html_path
    except Exception as e:
        logging.error(f"Error visualizing network topology: {str(e)}")
        return None
